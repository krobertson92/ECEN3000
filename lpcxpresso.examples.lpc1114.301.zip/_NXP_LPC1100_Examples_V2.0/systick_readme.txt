systick
=====================
Demonstration of using the Cortex systick timer. This timer is for generating
periodic interrupts for RTOS task context switching or implementing a software
realtime clock.
Look for a flashing LED; this LED is controlled by counting SYSTICK interrupts.