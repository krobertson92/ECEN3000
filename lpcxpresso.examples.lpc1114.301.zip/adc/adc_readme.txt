adc
=====================
This project uses the ADC to read voltages. It can print the voltages
out using a small printf routine and semihosting built in to the
LPCXpresso debugger window.

